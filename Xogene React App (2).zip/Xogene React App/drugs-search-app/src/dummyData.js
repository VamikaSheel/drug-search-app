// src/dummyData.js

export const dummyDrugs = [
    {
        name: 'Aspirin',
        rxcui: '123',
        synonyms: ['Acetylsalicylic Acid', 'ASA'],
    },
    {
        name: 'Ibuprofen',
        rxcui: '456',
        synonyms: ['Advil', 'Motrin'],
    },
    {
        name: 'Acetaminophen',
        rxcui: '789',
        synonyms: ['Tylenol', 'Paracetamol'],
    },
];
