import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import SearchPage from './components/SearchPage';
import DrugDetailPage from './components/DrugDetailPage';
import 'bootstrap/dist/css/bootstrap.min.css';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<SearchPage />} />
        <Route path="/drugs/:drugName" element={<DrugDetailPage />} />
      </Routes>
    </Router>
  );
};

export default App;
