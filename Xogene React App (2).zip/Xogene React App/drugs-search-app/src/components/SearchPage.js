import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

const dummyDrugs = [
  { name: "Aspirin", rxcui: "1234", synonym: ["Acetylsalicylic Acid", "ASA"] },
  { name: "Ibuprofen", rxcui: "5678", synonym: ["Advil", "Motrin"] },
  { name: "Amoxicillin", rxcui: "91011", synonym: ["Amoxil", "Trimox"] },
  { name: "Lisinopril", rxcui: "1213", synonym: ["Prinivil", "Zestril"] },
];

const SearchPage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [results, setResults] = useState([]);
  const [searched, setSearched] = useState(false);
  const navigate = useNavigate();

  const handleSearch = () => {
    const filteredDrugs = dummyDrugs.filter((drug) =>
      drug.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setResults(filteredDrugs);
    setSearched(true);
  };

  return (
    <div className="container mt-4">
      <h2 style={{ textAlign: "center" }}>Drug Search</h2>
      <div className="input-group mb-3">
        <input
          type="text"
          className="form-control"
          placeholder="Search for a drug..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        {/* Search button to trigger the search functionality */}
        <button className="btn btn-primary" onClick={handleSearch}>
          Search
        </button>
      </div>

      {/* Show results only after a search is performed */}
      {searched && results.length > 0 ? (
        <div className="row">
          {results.map((drug) => (
            <div className="col-md-4 mb-3" key={drug.rxcui}>
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">{drug.name}</h5>
                  <p className="card-text">
                    <strong>RXCUI:</strong> {drug.rxcui}
                  </p>
                  <p className="card-text">
                    <strong>Synonyms:</strong> {drug.synonym.join(", ")}
                  </p>
                  <button
                    className="btn btn-primary"
                    onClick={() => navigate(`/drugs/${drug.name}`)}
                  >
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        searched && <p>No results found.</p> // Show "No results found." only after a search
      )}
    </div>
  );
};

export default SearchPage;
