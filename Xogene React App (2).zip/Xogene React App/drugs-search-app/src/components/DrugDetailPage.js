import React from 'react';
import { useParams } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const dummyDrugDetails = {
  "Aspirin": { name: "Aspirin", rxcui: "1234", synonym: ["Acetylsalicylic Acid", "ASA"], ndcs: ["12345-6789", "98765-4321"] },
  "Ibuprofen": { name: "Ibuprofen", rxcui: "5678", synonym: ["Advil", "Motrin"], ndcs: ["54321-0987"] },
  "Amoxicillin": { name: "Amoxicillin", rxcui: "91011", synonym: ["Amoxil", "Trimox"], ndcs: ["11111-2222"] },
  "Lisinopril": { name: "Lisinopril", rxcui: "1213", synonym: ["Prinivil", "Zestril"], ndcs: ["33333-4444"] }
};

const DrugDetailPage = () => {
  const { drugName } = useParams();
  const drugDetails = dummyDrugDetails[drugName];

  return (
    <div className="container mt-5">
      <h1 className="mb-4">{drugDetails ? drugDetails.name : 'Drug Not Found'}</h1>
      {drugDetails ? (
        <div className="card p-4">
          <h5 className="card-title">Drug Details</h5>
          <p><strong>RXCUI:</strong> {drugDetails.rxcui}</p>
          <p><strong>Synonyms:</strong> {drugDetails.synonym.join(', ')}</p>
          <p><strong>NDCs:</strong> {drugDetails.ndcs.join(', ')}</p>
        </div>
      ) : (
        <div className="alert alert-danger mt-3">
          Sorry, no details found for this drug.
        </div>
      )}
    </div>
  );
};

export default DrugDetailPage;